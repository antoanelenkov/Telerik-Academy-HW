﻿using System;

/*Write a program that reads three integer numbers N, K and S and an array of N elements from the console.
Find in the array a subset of K elements that have sum S or indicate about its absence*/


    class Program
    {
        static void Main(string[] args)
        {
        }
   }

