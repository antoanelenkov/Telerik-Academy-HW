﻿using System;
//Write a program that sorts an array of integers using the Merge sort algorithm.


//THE PROBLEM IS NOT SOLVED!!!



/*
class MergeSort
{
    static void Merge(int[] array, int left, int right)
    {
        int mid = (left + right) / 2;
        int[] leftArray = new int[mid];
        int[] rightArray = new int[mid];
        for (int i = 0; i < leftArray.Length; i++)
        {
            leftArray[i] = array[i];
        }
        for (int i = mid; i < array.Length; i++)
        {
            rightArray[i] = array[i];
        }
        int sumRightArray = 0;
        int sumLeftArray = 0;

        for (int i = 0; i < mid; i++)
        {
            sumLeftArray += leftArray[i];
        } for (int i = 0; i <= mid; i++)
        {
            sumRightArray += rightArray[i];
        }
        if (sumRightArray > sumLeftArray)
        {
            sumLeftArray = sumRightArray;
        }



    }

    static void MergeSort(int[] array, int left, int right)
    {

    }
    static void Main(string[] args)
    {
        int[] array = { 1, 4, 5, 6, 7, 3, 4, 5, 6, 7, 1, 7, 6, 5, 8 };


    }
}

*/